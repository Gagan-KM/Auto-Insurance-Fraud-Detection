﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;

namespace fraudDetection.Branch
{
    public partial class _NaiveBayesBulk : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetTestingData();
        }

        //function to get Data
        private void GetTestingData()
        {
            int serialNo = 1;

            DataTable tab = new DataTable();
            BLL obj = new BLL();

            tab = obj.GetTestingData();

            if (tab.Rows.Count > 0)
            {
                tblTestingDataset.Rows.Clear();

                tblTestingDataset.BorderStyle = BorderStyle.Double;
                tblTestingDataset.GridLines = GridLines.Both;
                tblTestingDataset.BorderColor = System.Drawing.Color.Black;

                TableRow headerrow = new TableRow();
                headerrow.Height = 30;
                headerrow.ForeColor = System.Drawing.Color.Black;
                headerrow.BackColor = System.Drawing.Color.Goldenrod;

                TableCell cell1 = new TableCell();
                cell1.Text = "<b>SLNo</b>";
                headerrow.Controls.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = "<b>RecordId</b>";
                headerrow.Controls.Add(cell2);

                TableCell cell3 = new TableCell();
                cell3.Text = "<b>DCOD_CRD</b>";
                headerrow.Controls.Add(cell3);

                TableCell cell4 = new TableCell();
                cell4.Text = "<b>DCRD_COPD</b>";
                headerrow.Controls.Add(cell4);

                TableCell cell5 = new TableCell();
                cell5.Text = "<b>DPE_COD</b>";
                headerrow.Controls.Add(cell5);

                TableCell cell51 = new TableCell();
                cell51.Text = "<b>CDS</b>";
                headerrow.Controls.Add(cell51);

                TableCell cell52 = new TableCell();
                cell52.Text = "<b>PCD</b>";
                headerrow.Controls.Add(cell52);

                TableCell cell53 = new TableCell();
                cell53.Text = "<b>CR</b>";
                headerrow.Controls.Add(cell53);

                TableCell cell61 = new TableCell();
                cell61.Text = "<b>PP</b>";
                headerrow.Controls.Add(cell61);

                TableCell cell62 = new TableCell();
                cell62.Text = "<b>CCC</b>";
                headerrow.Controls.Add(cell62);


                tblTestingDataset.Controls.Add(headerrow);

                for (int cnt = 0; cnt < tab.Rows.Count; cnt++)
                {
                    TableRow row = new TableRow();

                    TableCell cellSerialNo = new TableCell();
                    cellSerialNo.Width = 10;
                    cellSerialNo.Font.Size = 10;
                    cellSerialNo.Text = serialNo + cnt + ".";
                    row.Controls.Add(cellSerialNo);

                    TableCell cellRecord = new TableCell();
                    cellRecord.Text = tab.Rows[cnt]["RecordId"].ToString();
                    row.Controls.Add(cellRecord);

                    TableCell cellP1 = new TableCell();
                    cellP1.Text = tab.Rows[cnt]["P1"].ToString();
                    row.Controls.Add(cellP1);

                    TableCell cellP2 = new TableCell();
                    cellP2.Text = tab.Rows[cnt]["P2"].ToString();
                    row.Controls.Add(cellP2);

                    TableCell cellP3 = new TableCell();
                    cellP3.Text = tab.Rows[cnt]["P3"].ToString();
                    row.Controls.Add(cellP3);

                    TableCell cellP4 = new TableCell();
                    cellP4.Text = tab.Rows[cnt]["P4"].ToString();
                    row.Controls.Add(cellP4);

                    TableCell cellP5 = new TableCell();
                    cellP5.Text = tab.Rows[cnt]["P5"].ToString();
                    row.Controls.Add(cellP5);

                    TableCell cellP6 = new TableCell();
                    cellP6.Text = tab.Rows[cnt]["P6"].ToString();
                    row.Controls.Add(cellP6);

                    TableCell cellP7 = new TableCell();
                    cellP7.Text = tab.Rows[cnt]["P7"].ToString();
                    row.Controls.Add(cellP7);

                    TableCell cellP8 = new TableCell();
                    cellP8.Text = tab.Rows[cnt]["P8"].ToString();
                    row.Controls.Add(cellP8);


                    tblTestingDataset.Controls.Add(row);

                }

            }
            else
            {
                tblTestingDataset.Rows.Clear();
                tblTestingDataset.GridLines = GridLines.None;
                tblTestingDataset.BorderStyle = BorderStyle.None;

                TableHeaderRow row = new TableHeaderRow();
                TableHeaderCell cell = new TableHeaderCell();
                cell.ColumnSpan = 5;
                cell.Font.Bold = true;
                cell.ForeColor = System.Drawing.Color.Red;

                cell.Text = "No Testing Data Found!!!";


                row.Controls.Add(cell);
                tblTestingDataset.Controls.Add(row);

            }

        }

        string _timeNB = null;

        protected void btnPredict_Click(object sender, EventArgs e)
        {
            DataTable tab = new DataTable();
            BLL obj = new BLL();

            int serialNo = 1;

            tab = obj.GetTestingData();

            if (tab.Rows.Count > 0)
            {
                _arrayResult.Clear();

                tblOutput.Rows.Clear();

                tblOutput.BorderStyle = BorderStyle.Double;
                tblOutput.GridLines = GridLines.Both;
                tblOutput.BorderColor = System.Drawing.Color.Black;

                TableRow headerrow = new TableRow();
                headerrow.Height = 30;
                headerrow.ForeColor = System.Drawing.Color.Black;
                headerrow.BackColor = System.Drawing.Color.Goldenrod;

                TableCell cell0 = new TableCell();
                cell0.Text = "<b>SlNo</b>";
                headerrow.Controls.Add(cell0);

                TableCell cell1 = new TableCell();
                cell1.Text = "<b>Record No</b>";
                headerrow.Controls.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = "<b>Result</b>";
                headerrow.Controls.Add(cell2);

                tblOutput.Controls.Add(headerrow);

                var watch = System.Diagnostics.Stopwatch.StartNew();

                for (int i = 0; i < tab.Rows.Count; i++)
                {
                    TableRow row = new TableRow();

                    TableCell cellSerialNo = new TableCell();
                    cellSerialNo.Width = 10;
                    cellSerialNo.Font.Size = 10;
                    cellSerialNo.Text = serialNo + i + ".";
                    row.Controls.Add(cellSerialNo);

                    TableCell cellP1 = new TableCell();
                    cellP1.Text = tab.Rows[i]["RecordId"].ToString();
                    row.Controls.Add(cellP1);


                    string _output = _NaiveBayesAlgorithmBulk(tab.Rows[i]["P1"].ToString(), tab.Rows[i]["P2"].ToString(), tab.Rows[i]["P3"].ToString(), tab.Rows[i]["P4"].ToString(), tab.Rows[i]["P5"].ToString(), tab.Rows[i]["P6"].ToString(), tab.Rows[i]["P7"].ToString(), tab.Rows[i]["P8"].ToString());


                    TableCell cellP2 = new TableCell();
                    cellP2.Text = _output;
                    row.Controls.Add(cellP2);

                    tblOutput.Controls.Add(row);
                }

                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                _timeNB = elapsedMs.ToString();

                Session["NB_Time"] = null;
                Session["NB_Time"] = _timeNB;

                ResultAnaly();
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Testing Data Not Found!!!')</script>");
            }
        }

        double pi;
        int nc, n;
        double result;
        ArrayList output = new ArrayList();
        ArrayList mul = new ArrayList();
        static ArrayList _arrayResult = new ArrayList();

        //function which contains the KNN algorithm steps
        private string _NaiveBayesAlgorithmBulk(string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8)
        {

            BLL obj = new BLL();
            ArrayList s = new ArrayList();
            string _output = null;

            output.Clear();

            s.Add("1");
            s.Add("0");

            int m = 8;
            double p = 0.5;

            string[] parameters = { "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8" };

            //reteriving the dataset
            DataTable tabDataset = new DataTable();
            tabDataset = obj.GetDataByBranch(Session["ICId"].ToString());

            if (tabDataset.Rows.Count > 0)
            {
                ArrayList _newClaim = new ArrayList();

                _newClaim.Add(p1);
                _newClaim.Add(p2);
                _newClaim.Add(p3);
                _newClaim.Add(p4);
                _newClaim.Add(p5);
                _newClaim.Add(p6);
                _newClaim.Add(p7);
                _newClaim.Add(p8);


                for (int i = 0; i < s.Count; i++)
                {
                    mul.Clear();

                    for (int j = 0; j < parameters.Length; j++)
                    {
                        n = 0;
                        nc = 0;

                        for (int d = 0; d < tabDataset.Rows.Count; d++)
                        {
                            if (tabDataset.Rows[d][j + 3].ToString().Equals(_newClaim[j]))
                            {
                                ++n;

                                if (tabDataset.Rows[d][m + 3].ToString().Equals(s[i]))

                                    ++nc;
                            }
                        }

                        double x = m * p;
                        double y = n + m;
                        double z = nc + x;

                        pi = z / y;
                        mul.Add(Math.Abs(pi));
                    }

                    double mulres = 1.0;

                    for (int z = 0; z < mul.Count; z++)
                    {
                        mulres *= double.Parse(mul[z].ToString());

                    }

                    result = mulres * p;
                    output.Add(Math.Abs(result));

                }
            }

            ArrayList _temp = new ArrayList();

            for (int x = 0; x < s.Count; x++)
            {
                _temp.Add(output[x]);
            }

            _temp.Sort();
            _temp.Reverse();

            for (int y = 0; y < s.Count; y++)
            {
                if (output[y].Equals(_temp[0]))
                {
                    //_output = s[y].ToString();

                    if (s[y].Equals("1"))
                    {
                        _output = "Fraud";
                    }
                    else
                    {
                        _output = "Normal";
                    }

                    _arrayResult.Add(s[y].ToString());

                    return _output;

                }
            }

            return _output;
        }

        double _outcomeCntNB = 0;

        private void ResultAnaly()
        {
            BLL obj = new BLL();
            DataTable tabActual = new DataTable();
            tabActual = obj.GetActualData();

            if (tabActual.Rows.Count > 0)
            {
                for (int i = 0; i < tabActual.Rows.Count; i++)
                {
                    if (tabActual.Rows[i]["Result"].ToString().Equals(_arrayResult[i].ToString()))
                    {
                        ++_outcomeCntNB;
                    }
                }

                Session["NB_Result"] = null;
                Session["NB_Result"] = _outcomeCntNB;

                tableResults.Rows.Clear();

                tableResults.BorderStyle = BorderStyle.Double;
                tableResults.GridLines = GridLines.Both;
                tableResults.BorderColor = System.Drawing.Color.SteelBlue;

                TableRow mainrow = new TableRow();
                mainrow.Height = 30;
                mainrow.ForeColor = System.Drawing.Color.Black;
                mainrow.BackColor = System.Drawing.Color.Goldenrod;

                TableCell cellC = new TableCell();
                cellC.Text = "<b>Naive Bayes</b>";
                mainrow.Controls.Add(cellC);

                TableCell cellB = new TableCell();
                cellB.Text = "<b>Constraint</b>";
                mainrow.Controls.Add(cellB);

                tableResults.Controls.Add(mainrow);

                //1st row
                TableRow row1 = new TableRow();

                TableCell cellAcc = new TableCell();
                cellAcc.Text = "<b>Accuracy</b>";
                row1.Controls.Add(cellAcc);

                TableCell cellAccNB = new TableCell();
                //cal
                double _percentageNB = (_outcomeCntNB / tabActual.Rows.Count) * 100;
                cellAccNB.Text = _percentageNB.ToString() + "%";
                row1.Controls.Add(cellAccNB);

                tableResults.Controls.Add(row1);

                //2nd row           
                TableRow row2 = new TableRow();

                TableCell cellTime = new TableCell();
                cellTime.Text = "<b>Time (milli secs)</b>";
                row2.Controls.Add(cellTime);

                TableCell cellTimeNB = new TableCell();
                cellTimeNB.Text = _timeNB;
                row2.Controls.Add(cellTimeNB);

                tableResults.Controls.Add(row2);

                //3rd row           
                TableRow row3 = new TableRow();

                TableCell cellCorrect = new TableCell();
                cellCorrect.Text = "<b>Correctly Classified</b>";
                row3.Controls.Add(cellCorrect);

                TableCell cellCorrectNB = new TableCell();
                cellCorrectNB.Text = _percentageNB.ToString() + "%";
                row3.Controls.Add(cellCorrectNB);

                tableResults.Controls.Add(row3);

                //4th row           
                TableRow row4 = new TableRow();

                TableCell cellInCorrect = new TableCell();
                cellInCorrect.Text = "<b>InCorrectly Classified</b>";
                row4.Controls.Add(cellInCorrect);

                TableCell cellInCorrectNB = new TableCell();
                cellInCorrectNB.Text = (100 - _percentageNB).ToString() + "%";
                row4.Controls.Add(cellInCorrectNB);

                tableResults.Controls.Add(row4);
            }
        }

      

    }
}