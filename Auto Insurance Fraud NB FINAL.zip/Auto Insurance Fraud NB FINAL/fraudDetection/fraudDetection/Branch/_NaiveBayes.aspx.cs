﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;

namespace fraudDetection.Branch
{
    public partial class _NaiveBayes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //txtP1.Focus();
        }

        protected void btnPredict_Click(object sender, EventArgs e)
        {
            NaiveBayesAlgorithm();
        }
               
        double pi;
        int nc, n;
        double result;
        ArrayList output = new ArrayList();
        ArrayList mul = new ArrayList();

        //function which contains the navie bayesian steps
        private void NaiveBayesAlgorithm()
        {
            try
            {
                BLL obj = new BLL();
                ArrayList s = new ArrayList();

                s.Add("1");
                s.Add("0");

                int m = 8;
                double p = 0.5;

                string[] parameters = { "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8" };
                               
                //reteriving the dataset
                DataTable tabDataset = new DataTable();
                tabDataset = obj.GetDataByBranch(Session["ICId"].ToString());

                if (tabDataset.Rows.Count > 0)
                {
                    ArrayList _newClaim = new ArrayList();

                    _newClaim.Add(txtP1.Text);
                    _newClaim.Add(txtP2.Text);
                    _newClaim.Add(txtP3.Text);
                    _newClaim.Add(txtP4.Text);
                    _newClaim.Add(txtP5.Text);
                    _newClaim.Add(txtP6.Text);
                    _newClaim.Add(txtP7.Text);
                    _newClaim.Add(txtP8.Text);
                    

                    for (int i = 0; i < s.Count; i++)
                    {
                        mul.Clear();

                        for (int j = 0; j < parameters.Length; j++)
                        {
                            n = 0;
                            nc = 0;

                            for (int d = 0; d < tabDataset.Rows.Count; d++)
                            {
                                if (tabDataset.Rows[d][j + 3].ToString().Equals(_newClaim[j]))
                                {
                                    ++n;

                                    if (tabDataset.Rows[d][m + 3].ToString().Equals(s[i]))

                                        ++nc;
                                }
                            }

                            double x = m * p;
                            double y = n + m;
                            double z = nc + x;

                            pi = z / y;
                            mul.Add(Math.Abs(pi));
                        }

                        double mulres = 1.0;

                        for (int z = 0; z < mul.Count; z++)
                        {
                            mulres *= double.Parse(mul[z].ToString());

                        }

                        result = mulres * p;
                        output.Add(Math.Abs(result));

                    }
                }

                ArrayList _temp = new ArrayList();

                for (int x = 0; x < s.Count; x++)
                {
                    _temp.Add(output[x]);
                }

                _temp.Sort();
                _temp.Reverse();

                for (int y = 0; y < s.Count; y++)
                {
                    if (output[y].Equals(_temp[0]))
                    {
                        lblResult.ForeColor = System.Drawing.Color.ForestGreen;
                        lblResult.Font.Bold = true;
                        lblResult.Font.Size = 16;

                        if (s[y].Equals("1"))
                        {
                            lblResult.Text = "Prediction [Naive Bayes]: " + "Fraud";
                        }
                        else
                        {
                            lblResult.Text = "Prediction [Naive Bayes]: " + "Genuine";
                        }

                        return;
                    }
                }
            }
            catch
            {

            }

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtP1.Text = "";
            txtP2.Text = "";
            txtP3.Text = "";
            txtP4.Text = "";
            txtP5.Text = "";
            txtP6.Text = "";
            txtP7.Text = "";
            txtP8.Text = "";
        }            

    }
}