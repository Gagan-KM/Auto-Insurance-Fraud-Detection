﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace fraudDetection.Branch
{
    public partial class frmDataset : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["ICId"] == null)
                {
                    Session.Abandon();
                    Response.Redirect("~/Public/frmLogin.aspx");
                }
                else
                {
                    GetData();
                }
            }
            catch
            {

            }
        }

        //function to get Data
        private void GetData()
        {
            int serialNo = 1;

            DataTable tab = new DataTable();
            BLL obj = new BLL();

            tab = obj.GetDataByBranch(Session["ICId"].ToString());

            if (tab.Rows.Count > 0)
            {
                tblDataset.Rows.Clear();

                tblDataset.BorderStyle = BorderStyle.Double;
                tblDataset.GridLines = GridLines.Both;
                tblDataset.BorderColor = System.Drawing.Color.Black;

                TableRow headerrow = new TableRow();
                headerrow.Height = 30;
                headerrow.ForeColor = System.Drawing.Color.Black;
                headerrow.BackColor = System.Drawing.Color.Goldenrod;

                TableCell cell1 = new TableCell();
                cell1.Text = "<b>SLNo</b>";
                headerrow.Controls.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = "<b>Date</b>";
                headerrow.Controls.Add(cell2);

                TableCell cell3 = new TableCell();
                cell3.Text = "<b>DCOD_CRD</b>";
                headerrow.Controls.Add(cell3);

                TableCell cell4 = new TableCell();
                cell4.Text = "<b>DCRD_COPD</b>";
                headerrow.Controls.Add(cell4);

                TableCell cell5 = new TableCell();
                cell5.Text = "<b>DPE_COD</b>";
                headerrow.Controls.Add(cell5);

                TableCell cell51 = new TableCell();
                cell51.Text = "<b>CDS</b>";
                headerrow.Controls.Add(cell51);

                TableCell cell52 = new TableCell();
                cell52.Text = "<b>PCD</b>";
                headerrow.Controls.Add(cell52);

                TableCell cell53 = new TableCell();
                cell53.Text = "<b>CR</b>";
                headerrow.Controls.Add(cell53);

                TableCell cell61 = new TableCell();
                cell61.Text = "<b>PP</b>";
                headerrow.Controls.Add(cell61);

                TableCell cell62 = new TableCell();
                cell62.Text = "<b>CCC</b>";
                headerrow.Controls.Add(cell62);

                TableCell cell63 = new TableCell();
                cell63.Text = "<b>RESULT</b>";
                headerrow.Controls.Add(cell63);


                TableCell cell6 = new TableCell();
                cell6.Text = "<b>Edit</b>";
                headerrow.Controls.Add(cell6);

                TableCell cell7 = new TableCell();
                cell7.Text = "<b>Delete</b>";
                headerrow.Controls.Add(cell7);

                tblDataset.Controls.Add(headerrow);

                for (int cnt = 0; cnt < tab.Rows.Count; cnt++)
                {
                    TableRow row = new TableRow();

                    TableCell cellSerialNo = new TableCell();
                    cellSerialNo.Width = 10;
                    cellSerialNo.Font.Size = 10;
                    cellSerialNo.Text = serialNo + cnt + ".";
                    row.Controls.Add(cellSerialNo);                                       
                   
                    TableCell cellDate = new TableCell();
                    cellDate.Width = 150;
                    cellDate.Text = tab.Rows[cnt]["Date"].ToString();
                    row.Controls.Add(cellDate);

                    TableCell cellP1 = new TableCell();                    
                    cellP1.Text = tab.Rows[cnt]["P1"].ToString();
                    row.Controls.Add(cellP1);

                    TableCell cellP2 = new TableCell();
                    cellP2.Text = tab.Rows[cnt]["P2"].ToString();
                    row.Controls.Add(cellP2);

                    TableCell cellP3 = new TableCell();
                    cellP3.Text = tab.Rows[cnt]["P3"].ToString();
                    row.Controls.Add(cellP3);

                    TableCell cellP4 = new TableCell();
                    cellP4.Text = tab.Rows[cnt]["P4"].ToString();
                    row.Controls.Add(cellP4);

                    TableCell cellP5 = new TableCell();
                    cellP5.Text = tab.Rows[cnt]["P5"].ToString();
                    row.Controls.Add(cellP5);

                    TableCell cellP6 = new TableCell();
                    cellP6.Text = tab.Rows[cnt]["P6"].ToString();
                    row.Controls.Add(cellP6);

                    TableCell cellP7 = new TableCell();
                    cellP7.Text = tab.Rows[cnt]["P7"].ToString();
                    row.Controls.Add(cellP7);

                    TableCell cellP8 = new TableCell();
                    cellP8.Text = tab.Rows[cnt]["P8"].ToString();
                    row.Controls.Add(cellP8);

                    TableCell cellResult = new TableCell();
                    cellResult.Text = tab.Rows[cnt]["Result"].ToString();
                    row.Controls.Add(cellResult);


                    TableCell cellEdit = new TableCell();

                    ImageButton btnEdit = new ImageButton();
                    btnEdit.Width = 15;
                    btnEdit.Height = 15;
                    btnEdit.ImageUrl = "~/images/edit-10-xxl.png";
                    btnEdit.ToolTip = "Click here to Edit the Data";
                    btnEdit.ID = "Edit~" + tab.Rows[cnt]["DataId"].ToString();

                    btnEdit.Click += new ImageClickEventHandler(btnEdit_Click);

                    cellEdit.Controls.Add(btnEdit);
                    row.Controls.Add(cellEdit);

                    TableCell cellDelete = new TableCell();

                    ImageButton btnDelete = new ImageButton();
                    btnDelete.Width = 15;
                    btnDelete.Height = 15;
                    btnDelete.ImageUrl = "~/images/deletebtn.jpg";
                    btnDelete.ToolTip = "Click here to Delete the Data";
                    btnDelete.ID = "Del~" + tab.Rows[cnt]["DataId"].ToString();
                    btnDelete.OnClientClick = "return confirm('Are you sure do you want to Delete')";
                    btnDelete.Click += new ImageClickEventHandler(btnDelete_Click);

                    cellDelete.Controls.Add(btnDelete);
                    row.Controls.Add(cellDelete);


                    tblDataset.Controls.Add(row);

                }

            }
            else
            {
                tblDataset.Rows.Clear();
                tblDataset.GridLines = GridLines.None;
                tblDataset.BorderStyle = BorderStyle.None;

                TableHeaderRow row = new TableHeaderRow();
                TableHeaderCell cell = new TableHeaderCell();
                cell.ColumnSpan = 5;
                cell.Font.Bold = true;
                cell.ForeColor = System.Drawing.Color.Red;

                cell.Text = "No Data Found!!!";


                row.Controls.Add(cell);
                tblDataset.Controls.Add(row);

            }

        }

        void btnEdit_Click(object sender, ImageClickEventArgs e)
        {
            BLL obj = new BLL();
            ImageButton btn = (ImageButton)sender;
            string[] s = btn.ID.ToString().Split('~');

            Session["D"] = null;
            Session["D"] = s[1];

            DataTable tab = new DataTable();
            tab = obj.GetDataById(int.Parse(s[1]));

            if (tab.Rows.Count > 0)
            {
                txtDate.Text = tab.Rows[0]["Date"].ToString();

                txtP1.Text = tab.Rows[0]["P1"].ToString();
                txtP2.Text = tab.Rows[0]["P2"].ToString();
                txtP3.Text = tab.Rows[0]["P3"].ToString();
                txtP4.Text = tab.Rows[0]["P4"].ToString();
                txtP5.Text = tab.Rows[0]["P5"].ToString();
                txtP6.Text = tab.Rows[0]["P6"].ToString();
                txtP7.Text = tab.Rows[0]["P7"].ToString();
                txtP8.Text = tab.Rows[0]["P8"].ToString();

                txtResult.Text = tab.Rows[0]["Result"].ToString();
            }

            btnAdd.Text = "Update";
        }

        //function to clear textboxes
        private void ClearTexts()
        {
            txtDate.Text = txtP1.Text = txtP2.Text = txtP3.Text = txtP4.Text = txtP5.Text = txtP6.Text = txtP7.Text = txtP8.Text = txtResult.Text = string.Empty;
        }

        void btnDelete_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ImageButton btn = (ImageButton)sender;

                BLL obj = new BLL();
                string[] s = btn.ID.Split('~');
                obj.DeleteData(int.Parse(s[1]));
                ClearTexts();
                ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Data Deleted Successfully!!!')</script>");
                GetData();
            }
            catch
            {
                ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Deletion Error!!!')</script>");
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                BLL obj = new BLL();

                if (btnAdd.Text == "Add")
                {
                    obj.InsertData(Session["ICId"].ToString(), DateTime.Now, int.Parse(txtP1.Text), int.Parse(txtP2.Text), int.Parse(txtP3.Text), int.Parse(txtP4.Text), int.Parse(txtP5.Text), int.Parse(txtP6.Text), int.Parse(txtP7.Text), int.Parse(txtP8.Text), int.Parse(txtResult.Text));
                    ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Data Added Successfully!!')</script>");
                    ClearTexts();
                    GetData();
                }
                else if (btnAdd.Text == "Update")
                {

                    obj.UpdateData(Session["ICId"].ToString(), DateTime.Now, int.Parse(txtP1.Text), int.Parse(txtP2.Text), int.Parse(txtP3.Text), int.Parse(txtP4.Text), int.Parse(txtP5.Text), int.Parse(txtP6.Text), int.Parse(txtP7.Text), int.Parse(txtP8.Text), int.Parse(txtResult.Text), int.Parse(Session["D"].ToString()));
                    ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Data Updated Successfully!!!')</script>");
                    ClearTexts();
                    GetData();
                    btnAdd.Text = "Add";                    
                }
            }
            catch
            {

            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtDate.Text = "";
            txtResult.Text = "";
            txtP1.Text = "";
            txtP2.Text = "";
            txtP3.Text = "";
            txtP4.Text = "";
            txtP5.Text = "";
            txtP6.Text = "";
            txtP7.Text = "";
            txtP8.Text = "";
        }

    }
}